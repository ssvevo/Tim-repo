import dns.resolver
import pyfiglet
import argparse
import requests
import dns
import sys

# Color Codes Table
RED = '\033[91m'
BLUE = '\033[94m'
CYAN = '\033[36m'
WHITE = '\033[97m'
GREEN = '\033[92m'
YELLOW = "\033[93m"
MAGENTA = "\033[35m"


# Font Style Code Table
BOLD = '\033[1m'
NORMAL = '\033[0m'
ITALIC = '\033[3m'


def banner():
	result = pyfiglet.figlet_format("Ozgon", font="small")
	print("{}{}{}{}".format(BOLD, WHITE, result, NORMAL) + "\t\t\t  {}{}{}bugDestroyer's{}\n".format(BLUE, ITALIC, BOLD, NORMAL))

def domain_check(domain):
	try:
		header = {'User-Agent': 'Mozilla/5.0'}
		url = 'http://' + domain
		res = requests.get(url, headers=header, timeout=2)
		codes = [200,201,202,203,204,205,206,300,302,303,307,308,400,401,402,403,404,405,406,1000,1001,1002,1003]
		statusCode = res.status_code
		if statusCode in codes:
			domain_check.status = statusCode
	except Exception as e:
		domain_check.status = None

def spf_checker(domain):
	try:
		spf_record = dns.resolver.resolve(domain, 'TXT')
		signs = ["+", "-", "~", "?"]
		for records in spf_record:
			for sign in signs:
				if sign == "-":
					if records.to_text().strip('"').startswith("v=spf1") and records.to_text().strip('"').endswith("{}all".format(sign)):
						print("\t{}{}Secured ({}all): {}{}\n\t\t└──────{} {}SPF{} => {}{}{}{}\n".format(MAGENTA, BOLD, sign, NORMAL, BOLD, NORMAL, YELLOW, NORMAL, CYAN, ITALIC, records.to_text().strip('"'), NORMAL))
				elif records.to_text().strip('"').startswith("v=spf1") and records.to_text().strip('"').endswith("{}all".format(sign)):
					print("\t{}{}Misconfigured ({}all): {}{}\n\t\t└──────{} {}SPF{} => {}{}{}{}\n".format(MAGENTA, BOLD, sign, NORMAL, BOLD, NORMAL, YELLOW, NORMAL, CYAN, ITALIC, records.to_text().strip('"'), NORMAL))
	except Exception as e:
		domain_check(domain)
		if domain_check.status is not None:
			print("\t\t{}└──────{} {}SPF{} => {}{}Vulnerable With SPF{}\n".format(BOLD, NORMAL, YELLOW, NORMAL, ITALIC, RED, NORMAL))
		else:
			print("\t\t{}└──────{} {}SPF{} => {}{}Domain Not Working{}\n".format(BOLD, NORMAL, YELLOW, NORMAL, ITALIC, RED, NORMAL)) 

def dmarc_check(domain):
	try:
		dmarc_record = dns.resolver.resolve("_dmarc.{}".format(domain), 'TXT')
		for records in dmarc_record:
			if records.to_text().strip('"').startswith("v=DMARC"):
				print("\t\t{}└──────{} {}DMARC{} => {}{}{}{}\n".format(BOLD, NORMAL, YELLOW, NORMAL, CYAN, ITALIC, records.to_text().strip('"'), NORMAL))
	except Exception as e:
		domain_check(domain.strip())
		if domain_check.status is not None:
			print("\t\t{}└──────{} {}DMARC{} => {}{}Vulnerable With DMARC{}\n".format(BOLD, NORMAL, YELLOW, NORMAL, ITALIC, RED, NORMAL))
		else:
			print("\t\t{}└──────{} {}DMARC{} => {}{}Domain Not Working{}\n".format(BOLD, NORMAL, YELLOW, NORMAL, ITALIC, RED, NORMAL)) 

# Argument List
ap = argparse.ArgumentParser(description="SPF & DMARC Record Checker", add_help=False)
ap.add_argument("-spf", dest="spf_finder", action="store_true", help="Find SPF Record.")
ap.add_argument("-dmarc", dest="dmarc_finder", action="store_true", help="Find DMARC Records.")
ap.add_argument("-d", "-domain", dest="domain", help="Domain to Check SPF or DMARC")
ap.add_argument("-l", "-list", dest="wordlist", help="TXT file of set of domains.")
ap.add_argument("-h", "--help", dest="help", action='help', default=argparse.SUPPRESS, help='Show this help message and exit.')
args = ap.parse_args()

def main():
	try:
		banner()

		# Finding SPF Reocrds
		if args.spf_finder and args.wordlist:
			print("{}{}{}Checking For SPF Reocrds: {}\n".format(YELLOW, BOLD, ITALIC, NORMAL))
			with open(args.wordlist, 'r+') as domains:
				for domain in domains:
					print("{}{}Domain: {}{}".format(GREEN, BOLD, NORMAL, domain.strip()))
					spf_checker(domain.strip())

		elif args.spf_finder and args.domain:
			print("{}{}{}Checking For SPF Reocrds: {}\n".format(YELLOW, BOLD, ITALIC, NORMAL))
			print("{}{}Domain: {}{}".format(GREEN, BOLD, NORMAL, args.domain))
			spf_checker(args.domain)

		# Finding DMARC Records
		elif args.dmarc_finder and args.wordlist:
			print("{}{}{}Checking For DMARC Reocrds: {}\n".format(YELLOW, BOLD, ITALIC, NORMAL))
			with open(args.wordlist, 'r+') as domains:
				for domain in domains:
					print("{}{}Domain: {}{}".format(GREEN, BOLD, NORMAL, domain.strip()))
					dmarc_check(domain.strip())

		elif args.dmarc_finder and args.domain:
			print("{}{}{}Checking For DMARC Reocrds: {}\n".format(YELLOW, BOLD, ITALIC, NORMAL))
			print("{}{}Domain: {}{}".format(GREEN, BOLD, NORMAL, args.domain))
			dmarc_check(args.domain)

		# Finding SPF & DMARC Records For Set of Domains
		elif args.wordlist:
			print("{}{}{}Checking For SPF & DMARC Reocrds: {}\n".format(YELLOW, BOLD, ITALIC, NORMAL))
			with open(args.wordlist, 'r+') as domains:
				for domain in domains:
					print("{}{}Domain: {}{}".format(GREEN, BOLD, NORMAL, domain.strip()))
					spf_checker(domain.strip())
					dmarc_check(domain.strip())

		elif args.domain:
			print("{}{}{}Checking For SPF & DMARC Reocrds: {}\n".format(YELLOW, BOLD, ITALIC, NORMAL))
			print("{}{}Domain: {}{}".format(GREEN, BOLD, NORMAL, args.domain))
			spf_checker(args.domain)
			dmarc_check(args.domain)

	except Exception as e:
		args.print_help()
		sys.exit(0)
