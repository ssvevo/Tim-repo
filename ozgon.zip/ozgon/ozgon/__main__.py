from ozgon.modules.ozgon import *

if __name__ == '__main__':
	main()