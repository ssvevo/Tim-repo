from setuptools import setup, find_packages

# with open("README.md", "r") as readme_file:
# 	long_description = readme_file.read()

setup(
	name="ozgon",
	version="0.1",
	url="/Users/nullr3x/Desktop/projects/Internal Tools/ozgon/",
	description="Ozgon is made in python used to check SPF & DMARC Records",
	# long_description=long_description,
	author="Sahil Mehra(nullr3x)",
	author_email="sahilmehra1337@gmail.com",
	license="MIT",
	keywords="SPF & DMARC Checker",
	packages=["ozgon", "ozgon.modules"],
	install_requires=['dnspython', 'pyfiglet', 'argparse', 'requests'],
	entry_points={
		'console_scripts':[
			'ozgon = ozgon.__main__:main'
		],
	},
)

